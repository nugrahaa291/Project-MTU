# Redesign MTU — branch absen

Ekstrak arsip, lalu buka perbandingan.html untuk membandingkan aplikasi pada commit bc0d2d9 dengan tampilan yang baru. Folder skenario berisi contoh tambahan ketika GPS ditolak dan berkas SKD memiliki nama panjang.

## Perubahan
Poppins disertakan lokal dengan lisensi SIL Open Font License. Teks utama berwarna gelap, aksi utama merah bata #a73520, dan navigasi serta petunjuk lokasi biru #205fa3. Beranda PWA memakai tepi 20 px dan memisahkan area gulir dari tombol Absen dan navigasi. Kategori dalam sheet berbentuk baris; waktu dan detail aktivitas berada pada kolom terpisah. Panel HRD memprioritaskan izin menunggu, merangkum statistik lain dan memberi label pada filter. Portal rekrutmen menampilkan posisi, lokasi dan batas lamaran per baris. Form menunjukkan jumlah isian wajib yang lengkap.

## Verifikasi
- npm run build berhasil tanpa peringatan.
- php artisan test lulus 125 tes dan 1689 assertion.
- node --test --test-force-exit tests/pwa/*.test.mjs lulus 43 tes tanpa tes dilewati.
- Chromium memeriksa 14 layar sebelum dan sesudah pada lebar 360, 390, 768 dan 1280 px. Tidak ada luapan horizontal pada dokumen dalam skenario ini.
- Skenario 360 px meliputi nama panjang, 12 aktivitas dengan tujuan panjang, izin lokasi ditolak, PDF SKD dengan nama panjang, dan indikator kelengkapan formulir lamaran.
- Halaman login /absen dan Poppins dapat dimuat ulang saat offline. Lighthouse Accessibility login mendapat 100/100.
- Pengujian visual menggunakan basis data SQLite contoh serta GPS dan kamera simulasi. Verifikasi fisik yang tersisa mencakup izin dan akurasi GPS di lapangan, mutu kamera depan, keterbacaan di bawah sinar matahari, keyboard Safari iOS, serta pemasangan di perangkat karyawan.

## File aplikasi yang berubah
- app/Http/Controllers/PwaController.php
- public/pwa/app.js
- public/pwa/fonts/Poppins-LICENSE
- public/pwa/fonts/poppins-latin-400-normal.woff2
- public/pwa/fonts/poppins-latin-500-normal.woff2
- public/pwa/fonts/poppins-latin-600-normal.woff2
- public/pwa/fonts/poppins-latin-700-normal.woff2
- public/pwa/fonts/poppins.css
- public/pwa/style.css
- public/pwa/sw.js
- resources/css/app.css
- resources/js/app.js
- resources/views/auth/login.blade.php
- resources/views/hrd/dashboard.blade.php
- resources/views/hrd/izin/index.blade.php
- resources/views/hrd/karyawan/index.blade.php
- resources/views/hrd/kegiatan/index.blade.php
- resources/views/hrd/lamaran/index.blade.php
- resources/views/layouts/panel.blade.php
- resources/views/layouts/publik.blade.php
- resources/views/publik/lamaran/create.blade.php
- resources/views/publik/lowongan/index.blade.php
- resources/views/publik/lowongan/show.blade.php
- resources/views/pwa/index.blade.php
