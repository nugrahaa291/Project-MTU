# Perubahan antarmuka MTU pada branch absen

## Penggunaan
Buka arsip, ekstrak seluruh isinya, lalu buka perbandingan.html. Setiap baris memasangkan tangkapan layar Chromium pada ukuran viewport yang sama. Fixture pengujian memakai akun dan data contoh, kamera virtual, lokasi simulasi dan font cadangan sistem.

## Perubahan
- PWA memakai penekanan visual pada jam server dan tombol Absen. Riwayat aktivitas baru dikelompokkan menurut tanggal. Sheet mempunyai fokus keyboard, indikator empat langkah Order, kontrol besar, penghitung panjang alasan dan umpan balik lokasi. Pengambilan ulang lokasi saat selfie serta tombol Coba Lagi tetap mengikuti alur semula. Cache kerangka halaman memakai absen-v3.
- Panel menempatkan jumlah izin tertunda di awal dashboard. HRD dapat melihat siapa yang mengajukan dan siapa penggantinya sebelum menyetujui. Filter aktivitas berlabel, tabel lebar memberi petunjuk gulir, tombol kirim menunjukkan proses.
- Portal menampilkan persyaratan posisi, jumlah isian wajib yang lengkap, tautan langsung ke kesalahan validasi, nama dan ukuran berkas, serta tombol salin kode lamaran dengan pilihan teks cadangan.
- Identitas Hind, koral #f8694a dan tinta #30323a dipertahankan. Token teks aksen --aksen-teks dan --color-brand-dark memakai #a73520 untuk keterbacaan. Token --fokus dan --color-focus memakai #205fa3 untuk navigasi keyboard. --color-line diselaraskan dengan garis PWA #e7e8ec.

## Verifikasi
- npm run build berhasil tanpa peringatan.
- php artisan test lulus 125 tes dengan 1689 assertion.
- node --test --test-force-exit tests/pwa/*.test.mjs lulus 43 tes, termasuk jsdom, tanpa tes dilewati.
- Chromium, lebar 360, 390, 768 dan 1280 px. Sebanyak 14 tampilan sebelum dan sesudah, total 112 PNG. Tidak ditemukan overflow horizontal pada dokumen dalam skenario tangkapan layar.
- Lighthouse Accessibility pada login /absen mendapat 100/100. Hasil audit ada dalam lighthouse.json.
- Chromium dengan profil persisten melaporkan nol kesalahan kelayakan instalasi. Kerangka login bisa dimuat ulang saat jaringan dimatikan.
- Perlu verifikasi manual pada Safari iOS dan HP driver untuk akurasi GPS, izin kamera, keyboard, pemasangan aktual ke layar utama, serta keterbacaan di bawah sinar matahari. Foto, lokasi dan pengiriman absensi perangkat nyata tidak termasuk pengujian ini.

## File aplikasi
- public/pwa/app.js
- public/pwa/style.css
- public/pwa/sw.js
- resources/css/app.css
- resources/js/app.js
- resources/views/auth/login.blade.php
- resources/views/components/field.blade.php
- resources/views/hrd/dashboard.blade.php
- resources/views/hrd/izin/index.blade.php
- resources/views/hrd/kegiatan/index.blade.php
- resources/views/layouts/panel.blade.php
- resources/views/layouts/publik.blade.php
- resources/views/publik/lamaran/berhasil.blade.php
- resources/views/publik/lamaran/create.blade.php
- resources/views/publik/lowongan/index.blade.php
- resources/views/publik/lowongan/show.blade.php
- resources/views/publik/status.blade.php
- resources/views/pwa/index.blade.php
